from termcolor import colored
from tabulate import tabulate
import openai
import requests
import json
import requests
from bs4 import BeautifulSoup
import pandas as pd
import urllib.request
import re
from urllib.request import urlopen
from youtube_transcript_api import YouTubeTranscriptApi
import pyttsx3
from tqdm import tqdm

google_api_key = "" # YOUR GOOGLE API KEY
google_engine_index = "974f71f92973b4990"
openai_api_key = "" # YOUR OPENAI API KEY (API key creation is free, but for to use the models used in the code, you should pay)
openai.api_key = openai_api_key

def ask_google(query) :
    url = f"https://www.googleapis.com/customsearch/v1?key={google_api_key}&cx={google_engine_index}&q={query}"
    response = requests.get(url)
    data = json.loads(response.text)

    # Check for errors or empty search results
    if 'error' in data:
        print("Error:", data['error']['message'])
    elif 'items' not in data:
        print("No search results found.")
    else:
        # Extract search results
        search_results = data['items']

        columns = ['Title', 'Link']
        df = pd.DataFrame(columns=columns)

        for result in search_results:
            title = result['title']
            link = result['link']
            df = df._append({'Title': title, 'Link': link}, ignore_index=True)

        # Display the DataFrame
    return df

def generate_summary(huge_text):
    try :
        chunk_size = 4000  # Adjust as needed to stay below the token limit
        summary = ""
        
        # Split the huge text into chunks
        chunks = [huge_text[i:i+chunk_size] for i in range(0, len(huge_text), chunk_size)]
        
        # Process each chunk separately and concatenate the summaries
        for chunk in chunks:
            response = openai.Completion.create(
                engine="gpt-3.5-turbo-instruct",
                prompt=f"You are a good model. Please summarize the following text in not more than one paragraph (Please strictly do not write more than one paragraph). You can cut off non-completed words. Make sure the meaning holds \n\n {chunk}",
                max_tokens=500,  # Adjust as needed
                temperature=1,
                top_p=1,
                frequency_penalty=0,
                presence_penalty=0
            )
            summary += response.choices[0].text.strip() + " "
        
        return summary.strip()
    except Exception as e:
        return "No sufficient and suitable content found."

import urllib.request

def scrape(url):
    try :
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
        }
        
        # Create a Request object with headers
        request = urllib.request.Request(url, headers=headers)
        
        # Open the URL with the Request object
        scraped_data = urllib.request.urlopen(request)
        
        article = scraped_data.read()
        parsed_article = BeautifulSoup(article, "html.parser")

        paragraphs = parsed_article.find_all('p')

        text = ""

        for p in paragraphs:
            text += p.text
            
        return text
    except Exception as e:
        return ""

def gogle_summarize(query):
    results = ask_google(query)
    titles = results['Title']
    links = results['Link']
    data = list(zip(titles, [colored(link, "blue") for link in links]))

    # Print the tabulated table
    print(tabulate(data, headers=[colored('Title of the Webpage', "red"), colored('Link to visit', "red")], tablefmt='grid'))
    print("\n")
    summary = ""    
    try:
        with tqdm(total=3, ascii=' #', desc='Summarizing ', bar_format='{desc}: [{bar}]{percentage:3.0f} %') as pbar:
            for ind in range(3):
                text_in_web = scrape(links[ind])
                page_summary = generate_summary(text_in_web)
                summary += "\n\n" + page_summary
                pbar.update(1)
        final_summary = generate_summary(summary)
        final_summary = "\n" + final_summary.split("\n")[-1]

    except Exception as e:
        final_summary = "Unable to generate a summary. This might be due to insufficient text content on the main webpages."
    return final_summary


def gogle_page_summarize(url) :
    text = scrape(url)
    summary = generate_summary(text)
    return summary

def read_aloud(text):
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()