import Gogle as gogle
import transcript as transcript
import logo as banner
import keyboard
import time
from termcolor import colored

running = True
read_aloud = False

def enable_read_aloud():
    global read_aloud
    read_aloud = True
    print(f"{colored("Gogle >> ", "green")}{colored("Succesfully enabled Read-Aloud for upcoming results.", "blue")}")
    print("\n")

def disable_read_aloud():
    global read_aloud
    read_aloud = False
    print(f"{colored("Gogle >> ", "green")}{colored("Succesfully disabled Read-Aloud for upcoming results.", "blue")}")
    print("\n")

def end_session():
    global running
    print(colored("Initiating exit...", "red"))
    time.sleep(0.1)
    print(colored("Exiting Gogle...", "red"))
    running = False

def query_summarize():
    print(f"Mode : Summarizing a {colored("Search", "red")} \n")
    query = input(f"{colored("Gogle >> ", "red")}Ask anything : ")
    summary = gogle.gogle_summarize(query)
    print("\n",summary)
    if read_aloud :
        gogle.read_aloud(summary)
    print(f"\n{colored("Gogle >> Request processed. Hope you liked the response.", "green")}\n")

def webpage_summarize():
    print(f"Mode : Summarizing a {colored("Webpage", "red")} \n")
    page_url = input(f"{colored("Gogle >> ", "red")} Paste the URL of the web-page : ")
    summary = gogle.gogle_page_summarize(page_url)
    print(summary)
    if read_aloud :
        gogle.read_aloud(summary)
    print(f"\n{colored("Gogle >> Request processed. Hope you liked the response.", "green")}\n")

def video_summarize():
    print(f"Mode : Summarizing a {colored("Youtube video", "red")} \n")
    video_url = input(f"{colored("Gogle >> ", "red")} Paste the URL of the video here : ")
    transcript_text = transcript.gogle_transcript(video_url)
    transcript_summary = gogle.generate_summary(transcript_text)
    print(transcript_summary)
    if read_aloud :
        gogle.read_aloud(transcript_summary)
    print(f"\n{colored("Gogle >> Request processed. Hope you liked the response.", "green")}\n")

def video_transcript():
    print(f"Mode : Generating Youtube video {colored("Transcript", "red")} \n")
    video_url = input(f"{colored("Gogle >> ", "red")} Paste the URL of the video here : ")
    transcript_text = transcript.gogle_transcript(video_url)
    print(transcript_text)
    if read_aloud :
        gogle.read_aloud(transcript_text)
    print(f"\n{colored("Gogle >> Request processed. Hope you liked it.", "green")}\n")

keyboard.add_hotkey('ctrl + c', end_session)

keyboard.add_hotkey('ctrl + s', query_summarize)

keyboard.add_hotkey('ctrl + w', webpage_summarize) 

keyboard.add_hotkey('ctrl + y', video_summarize)

keyboard.add_hotkey('shift + y', video_transcript)

keyboard.add_hotkey('ctrl + h', banner.print_help_table)

keyboard.add_hotkey('ctrl + r', enable_read_aloud)

keyboard.add_hotkey('shift + r', disable_read_aloud)


# Listen for keypresses until Ctrl+Esc is pressed
while running:
    time.sleep(1)