from youtube_transcript_api import YouTubeTranscriptApi
from pytube import YouTube
from io import BytesIO
from tempfile import NamedTemporaryFile
from moviepy.editor import *
import assemblyai as aai
import requests
from io import BytesIO
import json
import time

def get_subtitles(youtube_url):
    try:
        video_id = youtube_url.split('?v=')[1]  # Extract video ID from URL
        transcript_list = YouTubeTranscriptApi.get_transcript(video_id)
        subtitles = ''
        for segment in transcript_list:
            subtitles += segment['text'] + ' '
        return subtitles.strip()
    except Exception as e:
        return ("Failed to extract subtitles, The most possible reason is that the provided video has no subtitles")

def extract_audio_from_video(url):
    yt = YouTube(url)
    audio_stream = yt.streams.filter(only_audio=True).first()
    audio_content = BytesIO()
    audio_stream.stream_to_buffer(audio_content)
    audio_content.seek(0)
    
    return audio_content

def transcribe_audio_from_bytesio(audio_bytes_io):
    base_url = "https://api.assemblyai.com/v2"

    headers = {
        "authorization": "a71d23dd92b6477983988cf41ccc0dff"
    }

    response = requests.post(base_url + "/upload", headers=headers, data=audio_bytes_io)

    upload_url = response.json()["upload_url"]

    data = {
        "audio_url": upload_url
    }

    url = base_url + "/transcript"
    response = requests.post(url, json=data, headers=headers)

    transcript_id = response.json()['id']
    polling_endpoint = f"https://api.assemblyai.com/v2/transcript/{transcript_id}"

    while True:
        transcription_result = requests.get(polling_endpoint, headers=headers).json()

        if transcription_result['status'] == 'completed':
            return transcription_result['text']

        elif transcription_result['status'] == 'error':
            raise RuntimeError(f"Transcription failed: {transcription_result['error']}")

        else:
            time.sleep(3)


def gogle_transcript(url):

    subtitles = get_subtitles(url)
    
    if subtitles == "Failed to extract subtitles, The most possible reason is that the provided video has no subtitles" :
        audio_io = extract_audio_from_video(url)
        subtitles = transcribe_audio_from_bytesio(audio_io)

    return subtitles


# Example usage
# url = 'https://www.youtube.com/watch?v=KUN5Uf9mObQ'
# print(gogle_transcript(url))
