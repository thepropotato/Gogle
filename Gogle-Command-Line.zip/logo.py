from termcolor import colored
import time
import os
from tabulate import tabulate

from art import *

def animation() :

    s1 = "|"
    s2 = "G|"
    s3 = "Go|"
    s4 = "Goo|"
    s5 = "Goog|"
    s6 = "Googl|"
    s7 = "Google|"
    s8 = "Googl|e"
    s9 = "Goog|le"
    s10 = "Goo|gle"
    s11 = "Go|gle"
    s12 = "Gogle"

    strings = [s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11]

    for string in strings :
        #print(pyfiglet.figlet_format(string, font="bulbhead"))
        print(colored(text2art(string, font="georgia11")))
        time.sleep(0.15)
        os.system('cls')

    print(colored(text2art(s12, font="georgia11"),  color="magenta"))
    print(colored("↤↤↤↤↤↤↤↤↤  𝙳𝚘𝚗'𝚝 𝚌𝚕𝚒𝚌𝚔. 𝙻𝚎𝚝 𝚞𝚜 𝚌𝚘𝚘𝚔. ↦↦↦↦↦↦↦↦↦", color="yellow"))

    for _ in range(1,48) :
        if _ != 47 :
            print("-", end="")
        else :
            print("-")

    print("\nWelcome to Gogle (Command Line Tool). If you are new around here, you can use gogle to...\n")
    time.sleep(0.5)
    print("➜  Search anything,", colored("get summarized results", color="green"), "along with the generalized google search results.")
    time.sleep(0.5)
    print("➜  Enter the", colored("URL of a web page", color="green"), "to get the summary of the page.")
    time.sleep(0.5)
    print("➜  Enter the", colored("URL of a youtube video", color="green"), "to get the summary of the video.")
    time.sleep(0.5)
    print("➜ ",colored("Listen", color="green"), "to the results using the", colored("Read Aloud", color="green"), "option.")
    time.sleep(0.5)
    print("➜ ",colored("Click on", color="green"), "the returned URL results to", colored("open the original article on the web", color="green"), "in your default browser.")
    time.sleep(0.5)

def print_help_table():
    print("\n")
    print("Here are the list of valid key bindings and their actions in Gogle. \n")
    actions = ["Search anything (Ex : What is the capital of India ?)", "Summarize a Webpage (Ex : https://en.wikipedia.org/wiki/Filmmaking)", "Summarize a youtube video", "Show original transcript of a youtube video", "Enable Read Aloud for upcoming results", "Disable Read Aloud for upcoming results", "Open a returned URL", "Help / Show the list of valid keybindings and their corresponding actions","Exit Gogle"]
    keys = ["Ctrl + S", "Ctrl + W", "Ctrl + Y", "Shift + Y", "Ctrl + R", "Shift + R", "Ctrl + Click", "Ctrl + H", "Ctrl + C"]

    # Combine actions and keys into a list of tuples
    table_data = list(zip(actions, keys))

    # Print the table
    print(tabulate(table_data, headers=["\033[91mActions\033[0m", "\033[91mKey Bindings\033[0m"], tablefmt="grid"))
    print("\n")

animation()
print_help_table()