This .zip file is just to store the codebase.
You can download Gogle from the website directly.
Gogle.exe will be found on your system, once downloaded.